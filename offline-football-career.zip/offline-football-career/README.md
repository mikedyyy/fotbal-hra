# Career XI — offline football career simulator

Mobile-first football career simulation built with React, TypeScript, Vite and Capacitor. Core simulation and save data are local; no server or account is needed.

## Run locally

Requirements: Node.js 20+ and npm.

```bash
npm install
npm run dev
```

## Build web assets

```bash
npm run build
```

## Create Android project and APK

Requirements: Android Studio, Android SDK, and a JDK supported by your installed Android Gradle Plugin.

```bash
npm install
npx cap add android       # run once
npm run android:sync
npm run android:open
```

In Android Studio, wait for Gradle sync, then select **Build > Build Bundle(s) / APK(s) > Build APK(s)**. The debug APK is usually at `android/app/build/outputs/apk/debug/app-debug.apk`.

## Current prototype features

- Player creation, nationality, position, and starting club
- Real club names from a curated offline sample dataset
- Season simulation, player development, stats and trophies
- Transfer offers and club changes
- National team call-up flag
- Career history, trophy room and automatic local save
- Responsive mobile interface; no remote runtime dependencies

## Next development steps

- Expand league/team/player datasets and competition logic
- Add deterministic simulation tests and balancing
- Add proper badges/crests and licensed-data review
- Add Android app icons, splash screen, and device testing

Club names are included as factual references. This prototype is not affiliated with or endorsed by any club or the original inspiration site.
