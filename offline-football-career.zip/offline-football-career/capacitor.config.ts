import type { CapacitorConfig } from '@capacitor/cli';
const config: CapacitorConfig = { appId: 'cz.careerxi.offline', appName: 'Career XI', webDir: 'dist', bundledWebRuntime: false };
export default config;
